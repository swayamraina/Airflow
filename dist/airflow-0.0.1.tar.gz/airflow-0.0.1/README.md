# airflow
A simple CLI for basic server commands
