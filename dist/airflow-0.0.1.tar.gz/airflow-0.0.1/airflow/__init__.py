
# This file contains the package name for the 
# project.
#
# @author  Swayam Raina

name = 'airflow'