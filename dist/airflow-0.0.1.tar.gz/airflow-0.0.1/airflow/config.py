
# This file contains server level config. 'Airflow'
# leverages these constants to actually run server 
# level operations.
#
# @author  Swayam Raina

'''
    These hold server directory mappings.
    NOTE : Add new server instances here
'''
INSTANCE_1 = 'local'
INSTANCE_1_DIR = '/Users/b0205106/projects/portal-bheem'
INSTANCE_1_LOG_DIR = '/data/logs/portallog.log'


'''
    Instance property arrays. These are used for 
    comaprisons against user input.
'''
INSTANCES = [ 
    INSTANCE_1
]

INSTANCE_DIRS = [ 
    INSTANCE_1_DIR
]

INSTANCE_LOG_DIRS = [ 
    INSTANCE_1_LOG_DIR
]


'''
    Server config details.
'''
SERVER_PORT_FILEPATH = 'resources/application.properties'
SERVER_PORT_KEY = 'server.port'
HEARTBEAT_API = 'myairtelapp/v1/account/headers'


'''
    Application level properties
'''
GRADLE_TASK = 'devserver'
ENVIRONMENT = 'dev'
MACHINE_IP = '127.0.0.1'